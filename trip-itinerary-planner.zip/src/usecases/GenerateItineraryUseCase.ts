/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TripRequest, Itinerary, TravelStyle, BudgetLevel } from '../domain/entities';
import { ItineraryGateway } from '../adapters/ItineraryGateway';

export interface GenerateItineraryInput {
  destination: string;
  duration: number;
  style: TravelStyle;
  budget: BudgetLevel;
  customPreferences?: string;
}

/**
 * Use case that orchestrates the generation of an itinerary.
 * Does not depend on the UI framework, server framework, or specific Gemini SDK.
 */
export class GenerateItineraryUseCase {
  constructor(private readonly itineraryGateway: ItineraryGateway) {}

  public async execute(input: GenerateItineraryInput): Promise<Itinerary> {
    // 1. Create and validate the Enterprise entity
    const tripRequest = new TripRequest(
      input.destination,
      input.duration,
      input.style,
      input.budget,
      input.customPreferences || ''
    );

    // 2. Delegate to the outbound Interface Adapter gateway to interact with Gemini AI
    const itinerary = await this.itineraryGateway.generate(tripRequest);

    // 3. Perform any application-level post-processing or business checks
    if (!itinerary || itinerary.days.length !== tripRequest.duration) {
      throw new Error(`The generated plan was incomplete. Asked for ${tripRequest.duration} days, but received ${itinerary?.days?.length || 0} days.`);
    }

    return itinerary;
  }
}
