/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sparkles, Calendar, MapPin, Sliders, Briefcase, HelpCircle, Check } from 'lucide-react';
import { TravelStyle, BudgetLevel, TravelStyle as TStyle, BudgetLevel as TBudget } from '../domain/entities';

interface ItineraryFormProps {
  onSubmit: (data: {
    destination: string;
    duration: number;
    style: TravelStyle;
    budget: BudgetLevel;
    customPreferences: string;
  }) => void;
  isLoading: boolean;
}

export default function ItineraryForm({ onSubmit, isLoading }: ItineraryFormProps) {
  const [destination, setDestination] = useState('');
  const [duration, setDuration] = useState(5);
  const [style, setStyle] = useState<TravelStyle>('general');
  const [budget, setBudget] = useState<BudgetLevel>('midrange');
  const [customPreferences, setCustomPreferences] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Suggested destinations for quick input
  const suggestions = ['Kyoto, Japan', 'Paris, France', 'Reykjavik, Iceland', 'Cape Town, South Africa', 'Rome, Italy'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!destination.trim()) {
      setError('Destination is required.');
      return;
    }

    if (duration < 1 || duration > 14) {
      setError('Duration must be between 1 and 14 days.');
      return;
    }

    onSubmit({
      destination: destination.trim(),
      duration,
      style,
      budget,
      customPreferences: customPreferences.trim()
    });
  };

  const styleOptions: { value: TravelStyle; label: string; desc: string; emoji: string }[] = [
    { value: 'general', label: 'Balanced Explore', desc: 'A perfect mix of landmarks, dining, and adventure.', emoji: '🗺️' },
    { value: 'culture', label: 'Cultural & Historic', desc: 'Museums, ancient heritage, shrines, and archives.', emoji: '🏛️' },
    { value: 'relaxation', label: 'Relax & Wellness', desc: 'Spas, parks, leisurely walks, and zero rush.', emoji: '🧘' },
    { value: 'adventure', label: 'Thrill & Nature', desc: 'Hiking, outdoor exploration, and active sports.', emoji: '⛰️' },
    { value: 'foodie', label: 'Culinary Journey', desc: 'Gourmet hotspots, street food trails, and culinary classes.', emoji: '🍜' },
    { value: 'romantic', label: 'Romantic Escape', desc: 'Scenic vistas, intimate diners, and scenic cruises.', emoji: '💖' },
    { value: 'family', label: 'Family Friendly', desc: 'Interactive places, museums for children, and easy transit.', emoji: '🎡' }
  ];

  const budgetOptions: { value: BudgetLevel; label: string; desc: string; icon: string }[] = [
    { value: 'budget', label: 'Budget Traveler', desc: 'Hostels, public transport, free attractions.', icon: '$' },
    { value: 'midrange', label: 'Mid-Range', desc: 'Boutique stays, local diners, selective cabs.', icon: '$$' },
    { value: 'luxury', label: 'Premium Luxury', desc: '5-star suites, private guides, exclusive fine-dining.', icon: '$$$' }
  ];

  return (
    <form onSubmit={handleSubmit} className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-7 shadow-sm space-y-6 animate-slide-up">
      <div className="space-y-1 pb-4 border-b border-slate-100">
        <span className="text-[11px] font-bold text-indigo-600 uppercase tracking-widest block">Plan Architecture</span>
        <h2 className="font-display text-lg font-bold text-slate-800 tracking-tight flex items-center gap-2">
          <Sliders className="h-4 w-4 text-indigo-600" />
          NomadFlow Parameters
        </h2>
        <p className="text-xs text-slate-500">Configure parameters to compile secure itinerary nodes.</p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-100 text-red-700 p-3 rounded-lg text-xs flex items-start gap-2.5">
          <HelpCircle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Destination Section */}
      <div className="space-y-2">
        <label className="block text-xs font-semibold text-slate-700 flex items-center gap-1.5" id="label-destination">
          <MapPin className="h-3.5 w-3.5 text-indigo-500" />
          Target Destination
        </label>
        <div className="relative">
          <input
            id="input-destination"
            type="text"
            className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-500/20 placeholder-slate-400 font-medium px-3.5 py-2 rounded-xl transition duration-200 outline-none text-sm text-slate-900"
            placeholder="Search destination, e.g., Kyoto, Japan"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            required
            disabled={isLoading}
          />
        </div>
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Suggestions:</span>
          {suggestions.map((suggestion) => (
            <button
              id={`suggest-${suggestion.replace(/\s+/g, '-').toLowerCase()}`}
              key={suggestion}
              type="button"
              onClick={() => setDestination(suggestion)}
              className="text-[11px] bg-slate-50 border border-slate-150 hover:border-indigo-300 hover:bg-indigo-50 text-slate-600 px-2 py-0.5 rounded-md font-semibold transition cursor-pointer"
              disabled={isLoading}
            >
              {suggestion}
            </button>
          ))}
        </div>
      </div>

      {/* Duration Slider Section */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="block text-xs font-semibold text-slate-705 flex items-center gap-1.5" id="label-duration">
            <Calendar className="h-3.5 w-3.5 text-indigo-500" />
            Trip Duration
          </label>
          <span className="font-mono text-[11px] bg-indigo-50 text-indigo-700 font-bold px-2 py-1 rounded border border-indigo-100">
            {duration} {duration === 1 ? 'Day' : 'Days'}
          </span>
        </div>
        <div className="pt-1.5">
          <input
            id="input-duration-range"
            type="range"
            min="1"
            max="14"
            step="1"
            className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            value={duration}
            onChange={(e) => setDuration(parseInt(e.target.value))}
            disabled={isLoading}
          />
          <div className="flex justify-between text-[9px] text-slate-400 font-bold tracking-tight pt-1">
            <span>1 Day</span>
            <span>3d</span>
            <span>5d</span>
            <span>7d</span>
            <span>10d</span>
            <span>12d</span>
            <span>14 Days Max</span>
          </div>
        </div>
      </div>

      {/* Travel Vibe/Style Grid */}
      <div className="space-y-2">
        <label className="block text-xs font-semibold text-slate-700" id="label-travel-style">
          Pace Vibe Style
        </label>
        <div className="grid grid-cols-1 gap-2">
          <select
            id="style-select"
            value={style}
            onChange={(e) => setStyle(e.target.value as TravelStyle)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-md text-sm text-slate-800 font-medium outline-none focus:ring-2 focus:ring-indigo-500/20"
            disabled={isLoading}
          >
            {styleOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.emoji} {opt.label} — {opt.desc}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Budget Selector */}
      <div className="space-y-2">
        <label className="block text-xs font-semibold text-slate-700 flex items-center gap-1.5" id="label-budget">
          <Briefcase className="h-3.5 w-3.5 text-indigo-500" />
          Budget Tier
        </label>
        <div className="grid grid-cols-3 gap-2">
          {budgetOptions.map((opt) => (
            <button
              id={`budget-btn-${opt.value}`}
              key={opt.value}
              type="button"
              onClick={() => setBudget(opt.value)}
              className={`py-2 px-1.5 rounded-lg border text-center transition flex flex-col items-center gap-0.5 cursor-pointer ${
                budget === opt.value
                  ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
              disabled={isLoading}
            >
              <span className="font-mono text-xs font-bold leading-none">{opt.icon}</span>
              <span className="text-[10px] font-bold tracking-tight">{opt.label.split(' ')[0]}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Custom preferences */}
      <div className="space-y-1.5">
        <label className="block text-xs font-semibold text-slate-700 flex items-center gap-1.5" id="label-notes">
          Special Accommodations
          <span className="text-[10px] text-slate-400 font-normal">(Optional)</span>
        </label>
        <textarea
          id="input-preferences"
          className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-500/20 placeholder-slate-400 font-medium px-3 py-2 rounded-xl transition duration-200 outline-none text-xs text-slate-800 h-16 resize-none"
          placeholder="e.g. Vegetarian diet, wheelchair-friendly, early schedule..."
          value={customPreferences}
          onChange={(e) => setCustomPreferences(e.target.value)}
          disabled={isLoading}
          maxLength={500}
        />
        <div className="flex justify-between text-[9px] text-slate-450 px-1 font-semibold">
          <span>Personalization constraints</span>
          <span>{customPreferences.length}/500</span>
        </div>
      </div>

      {/* Submit Button */}
      <button
        id="submit-form-btn"
        type="submit"
        disabled={isLoading}
        className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl shadow transition active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none cursor-pointer flex items-center justify-center gap-2 text-xs uppercase tracking-wider"
      >
        {isLoading ? (
          <>
            <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            <span>Compiling Route Nodes...</span>
          </>
        ) : (
          <>
            <Sparkles className="h-4 w-4" />
            <span>Generate Itinerary</span>
          </>
        )}
      </button>

      {/* Clean Architecture Info Box from Design HTML */}
      <div className="p-4 bg-slate-900 rounded-xl text-white mt-4 select-none">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Interface Adapter</span>
          <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
        </div>
        <p className="text-[11px] text-slate-300 leading-relaxed font-normal">
          Dependency Rule enforced. Domain logic isolated from UI frameworks. Inputs verified via secure controller sanitization.
        </p>
      </div>
    </form>
  );
}
