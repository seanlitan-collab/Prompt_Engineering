/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Camera, Utensils, Compass, ShoppingBag, Heart, Car, 
  MapPin, Clock, Calendar, CheckSquare, Info, 
  Luggage, Globe, DollarSign, ShieldAlert, ThermometerSun, 
  ExternalLink, Printer, ClipboardCheck, ArrowRight
} from 'lucide-react';
import { Itinerary, Activity, DayPlan } from '../domain/entities';

interface ItineraryDisplayProps {
  itinerary: Itinerary;
  onSave?: (itinerary: Itinerary) => void;
  isSaved?: boolean;
}

export default function ItineraryDisplay({ itinerary, onSave, isSaved = false }: ItineraryDisplayProps) {
  const [activeDay, setActiveDay] = useState(1);
  const [copied, setCopied] = useState(false);

  const getCategoryTheme = (category: string) => {
    switch (category) {
      case 'food':
        return {
          bg: 'bg-orange-50 border-orange-100/50',
          text: 'text-orange-700',
          iconBg: 'bg-orange-100 text-orange-600',
          icon: Utensils
        };
      case 'adventure':
        return {
          bg: 'bg-emerald-50 border-emerald-100/50',
          text: 'text-emerald-700',
          iconBg: 'bg-emerald-100 text-emerald-600',
          icon: Compass
        };
      case 'shopping':
        return {
          bg: 'bg-pink-50 border-pink-100/50',
          text: 'text-pink-700',
          iconBg: 'bg-pink-100 text-pink-600',
          icon: ShoppingBag
        };
      case 'relaxation':
        return {
          bg: 'bg-indigo-50 border-indigo-100/50',
          text: 'text-indigo-700',
          iconBg: 'bg-indigo-100 text-indigo-600',
          icon: Heart
        };
      case 'transport':
        return {
          bg: 'bg-slate-50 border-slate-100/50',
          text: 'text-slate-700',
          iconBg: 'bg-slate-100 text-slate-600',
          icon: Car
        };
      case 'sightseeing':
      default:
        return {
          bg: 'bg-sky-50 border-sky-100/50',
          text: 'text-sky-700',
          iconBg: 'bg-sky-100 text-sky-600',
          icon: Camera
        };
    }
  };

  const currentDayData = itinerary.days.find(d => d.dayNumber === activeDay) || itinerary.days[0];

  const handleCopy = () => {
    try {
      const txt = `TRIP TO: ${itinerary.destination}\nDuration: ${itinerary.duration} Days\nTravel Mode: ${itinerary.style} (${itinerary.budget})\n\nOVERVIEW:\n${itinerary.overview}\n\n` +
        itinerary.days.map(d => `DAY ${d.dayNumber}: ${d.theme}\nDaily Tip: ${d.dailyTip}\nActivities:\n` + 
          d.activities.map(a => `- [${a.timeRange}] ${a.title} @ ${a.location}\n  ${a.description}`).join('\n')
        ).join('\n\n');
      navigator.clipboard.writeText(txt);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6 animate-slide-up" id="itinerary-display-container">
      
      {/* PROFESSIONAL POLISH: CURRENT USE CASE HEADER */}
      <header className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="space-y-1">
          <span className="text-indigo-600 font-bold text-xs tracking-wider uppercase block">
            Current Use Case
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {itinerary.destination}
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm leading-relaxed max-w-2xl font-normal">
            Strategic {itinerary.duration}-day travel itinerary mapped to optimized destination nodes.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button 
            id="export-json-btn"
            onClick={() => {
              const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(itinerary, null, 2));
              const downloadAnchor = document.createElement('a');
              downloadAnchor.setAttribute("href", dataStr);
              downloadAnchor.setAttribute("download", `itinerary_${itinerary.destination.toLowerCase().replace(/[^a-z0-9]+/g, '_')}.json`);
              document.body.appendChild(downloadAnchor);
              downloadAnchor.click();
              downloadAnchor.remove();
            }}
            className="px-3.5 py-2 border border-slate-200 rounded-lg text-xs font-bold bg-white text-slate-700 hover:bg-slate-50 transition cursor-pointer shadow-sm flex items-center gap-1.5"
          >
            Export JSON
          </button>
          
          {onSave && (
            <button
              id="save-itinerary-btn"
              onClick={() => onSave(itinerary)}
              disabled={isSaved}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer shadow-sm ${
                isSaved 
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : 'bg-slate-900 text-white hover:bg-slate-800'
              }`}
            >
              {isSaved ? 'Saved to Collection' : 'Save Plan'}
            </button>
          )}
        </div>
      </header>

      {/* TRIP OVERVIEW CARD */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-450 uppercase tracking-widest">
            Itinerary Synthesis Overview
          </span>
          <span className="px-2.5 py-0.5 bg-indigo-50 border border-indigo-100 text-indigo-700 text-[10px] font-bold uppercase rounded">
            {itinerary.style} vibe • {itinerary.budget}
          </span>
        </div>
        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
          {itinerary.overview}
        </p>

        {/* Short Stats Vitals Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-200">
          <div className="space-y-0.5">
            <span className="text-[9px] text-slate-400 font-bold uppercase">Days Scheduled</span>
            <p className="text-xs font-bold text-slate-800 font-mono">0{itinerary.duration}</p>
          </div>
          <div className="space-y-0.5">
            <span className="text-[9px] text-slate-400 font-bold uppercase">Budget Level</span>
            <p className="text-xs font-bold text-slate-800 capitalize">{itinerary.budget}</p>
          </div>
          <div className="space-y-0.5">
            <span className="text-[9px] text-slate-400 font-bold uppercase">Optimal Window</span>
            <p className="text-xs font-bold text-slate-800 font-mono text-ellipsis overflow-hidden whitespace-nowrap">{itinerary.practicalInfo.bestTimeToVisit}</p>
          </div>
          <div className="space-y-0.5">
            <span className="text-[9px] text-slate-400 font-bold uppercase">System State</span>
            <p className="text-xs font-mono font-bold text-emerald-600">ISOLATED_OK</p>
          </div>
        </div>
      </div>

      {/* 2. TABULATED DAYS NAVIGATOR */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-indigo-600" />
            Route Node Navigator
          </h3>
          <span className="text-[10px] bg-slate-100 text-slate-500 font-bold font-mono px-2 py-0.5 rounded">
            Node {activeDay} / {itinerary.duration}
          </span>
        </div>

        {/* Elegant Flat Day Buttons */}
        <div className="flex gap-1.5 overflow-x-auto pb-1.5 scrollbar-none select-none">
          {itinerary.days.map((day) => (
            <button
              id={`tab-day-${day.dayNumber}`}
              key={day.dayNumber}
              onClick={() => setActiveDay(day.dayNumber)}
              className={`px-3.5 py-1.5 rounded-lg font-bold text-xs transition tracking-tight shrink-0 border cursor-pointer ${
                activeDay === day.dayNumber
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              Day {day.dayNumber}
            </button>
          ))}
        </div>

        {/* Current Day Boarding theme */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shadow-xs">
          <div className="space-y-0.5">
            <span className="text-[9px] text-indigo-600 font-bold uppercase tracking-wider font-mono block">Active Day Theme</span>
            <h4 className="text-sm font-bold text-slate-800">{currentDayData.theme}</h4>
          </div>
          <div className="flex gap-2">
            <span className="bg-slate-50 border border-slate-200 text-slate-600 text-[10px] font-bold uppercase py-1 px-2.5 rounded-full font-mono">
              Estimated: {currentDayData.estimatedCost}
            </span>
          </div>
        </div>

        {/* Activities Timeline - matching the design grid/list concept */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {currentDayData.activities.map((activity, idx) => {
            const config = getCategoryTheme(activity.category);
            const IconComponent = config.icon;

            return (
              <div 
                id={`activity-${activity.id}`}
                key={activity.id} 
                className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col relative overflow-hidden transition hover:border-slate-350"
              >
                {/* Large stylized index number in background */}
                <div className="absolute top-1 right-2 text-3xl font-black text-slate-50 italic select-none pointer-events-none">
                  0{idx + 1}
                </div>

                <div className="flex justify-between items-start mb-3 relative z-10">
                  <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase border tracking-tight ${config.bg} ${config.text}`}>
                    {activity.category}
                  </span>
                  <span className="font-mono text-[9px] text-slate-400 font-bold">
                    {activity.timeRange.split(' - ')[0]}
                  </span>
                </div>

                <h5 className="text-sm font-bold text-slate-800 mb-1 relative z-10 leading-tight">
                  {activity.title}
                </h5>

                <p className="text-slate-500 text-[11px] leading-relaxed flex-1 font-normal mb-3">
                  {activity.description}
                </p>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-450 font-semibold font-mono">
                  <span className="truncate max-w-[120px] flex items-center gap-1">
                    <MapPin className="h-3 w-3 inline text-slate-300" />
                    {activity.location.split(',')[0]}
                  </span>
                  <span className="bg-slate-50 px-1.5 py-0.5 rounded text-slate-600">
                    {activity.estimatedCost}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Advisory Tips with Info styling from theme */}
        <div className="bg-amber-50/50 border border-amber-200 rounded-xl p-3.5 flex gap-2.5 items-start">
          <Info className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <h6 className="text-[10px] font-bold text-amber-800 uppercase tracking-wider font-mono">Advisory Node Tip</h6>
            <p className="text-[11px] text-amber-700 font-medium leading-relaxed">{currentDayData.dailyTip}</p>
          </div>
        </div>
      </div>

      {/* 4. RECOMMENDED PACKING CHECKLIST */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="border-b border-slate-100 pb-2">
          <span className="text-[11px] font-bold text-indigo-600 uppercase tracking-widest block">Resource Mappings</span>
          <h3 className="font-display text-sm font-bold text-slate-800 tracking-tight flex items-center gap-1.5">
            <Luggage className="h-4 w-4 text-indigo-600" />
            Recommended packing nodes
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {itinerary.packingList.map((pi, pIdx) => (
            <div 
              key={pIdx} 
              className="bg-slate-50/50 border border-slate-200 rounded-xl p-3 flex gap-2.5 items-start hover:bg-slate-50 transition"
            >
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-505 shrink-0 mt-2 bg-indigo-600"></div>
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs font-bold text-slate-800">{pi.item}</span>
                  <span className="capitalize text-[8px] bg-slate-100 border border-slate-200 text-slate-500 px-1.5 py-0.1 rounded font-bold">
                    {pi.category}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight font-normal">{pi.reason}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. PRACTICAL INFO VITALS FROM DESIGN SYSTEM */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="border-b border-slate-100 pb-2">
          <h3 className="font-display text-sm font-bold text-slate-800 tracking-tight flex items-center gap-1.5">
            <Globe className="h-4 w-4 text-slate-700" />
            Vitals & Local Knowledge
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-150 space-y-1">
            <span className="text-[9px] text-slate-450 font-bold uppercase">Currency & Customs</span>
            <p className="text-xs text-slate-700 font-semibold">{itinerary.practicalInfo.currency}</p>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-150 space-y-1">
            <span className="text-[9px] text-slate-450 font-bold uppercase">Primary Language</span>
            <p className="text-xs text-slate-700 font-semibold">{itinerary.practicalInfo.language}</p>
          </div>
          <div className="p-3 bg-red-50/20 rounded-lg border border-red-150/40 space-y-1">
            <span className="text-[9px] text-red-500 font-bold uppercase">Caution & Safety</span>
            <p className="text-xs text-red-700 font-semibold leading-snug">{itinerary.practicalInfo.safetyTip}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div className="p-3 bg-slate-50/50 rounded-lg border border-slate-200 space-y-1">
            <span className="text-[9px] text-slate-450 font-bold uppercase block">Transport Tip</span>
            <p className="text-[11px] text-slate-600 leading-normal font-normal">{itinerary.practicalInfo.transportTip}</p>
          </div>
          <div className="p-3 bg-slate-50/50 rounded-lg border border-slate-200 space-y-1">
            <span className="text-[9px] text-slate-450 font-bold uppercase block">Seasonal Window</span>
            <p className="text-[11px] text-slate-600 leading-normal font-normal">{itinerary.practicalInfo.bestTimeToVisit}</p>
          </div>
        </div>
      </section>

    </div>
  );
}
