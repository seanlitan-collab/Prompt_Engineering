/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Compass, ShieldCheck, AlertCircle } from 'lucide-react';

interface HeaderProps {
  isConfigured: boolean | null;
}

export default function Header({ isConfigured }: HeaderProps) {
  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center shadow-sm sticky top-0 z-50 transition-all duration-300">
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
        
        {/* Brand Logo and Title */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shrink-0">
            <div className="w-4 h-4 border-2 border-white rotate-45 flex items-center justify-center">
              <Compass className="h-2.5 w-2.5 text-white -rotate-45" />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold tracking-tight text-slate-800">
              Voyage<span className="text-indigo-600">Craft</span>
            </span>
            <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold uppercase rounded border border-emerald-100 tracking-wider">
              Vercel Deployed
            </span>
          </div>
        </div>

        {/* Configurations status / Secrets indicator */}
        <div className="flex items-center gap-4 sm:gap-6">
          {isConfigured === false ? (
            <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-700 px-3 py-1 rounded-lg text-xs font-medium max-w-xs sm:max-w-md">
              <AlertCircle className="h-4 w-4 shrink-0 text-amber-600" />
              <span className="hidden sm:inline">
                Gemini API Key missing. Configure in <b>Settings &gt; Secrets</b>.
              </span>
              <span className="sm:hidden">API Key Missing</span>
            </div>
          ) : (
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-600">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="hidden sm:inline">Security Layer: Active</span>
                <span className="sm:hidden">Active</span>
              </div>
              
              <div className="hidden md:flex px-2 py-0.5 bg-indigo-50 border border-indigo-100 text-indigo-700 text-[10px] font-bold uppercase rounded-md">
                Gemini-3.5-Flash
              </div>
            </div>
          )}
          
          <div className="h-8 w-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-500 font-bold text-xs" title="Traveler Context">
            TC
          </div>
        </div>

      </div>
    </header>
  );
}
