/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Bookmark, Trash2, Calendar, MapPin, Sparkles, Compass } from 'lucide-react';
import { Itinerary } from '../domain/entities';

interface HistoryPanelProps {
  savedPlans: Itinerary[];
  onSelect: (itinerary: Itinerary) => void;
  onDelete: (id: string) => void;
  selectedId?: string;
}

export default function HistoryPanel({ savedPlans, onSelect, onDelete, selectedId }: HistoryPanelProps) {
  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
      <div className="border-b border-slate-100 pb-3">
        <span className="text-[11px] font-bold text-indigo-600 uppercase tracking-widest block">Local Persistence</span>
        <h3 className="font-display text-sm font-bold text-slate-800 tracking-tight flex items-center gap-1.5">
          <Bookmark className="h-4 w-4 text-slate-700" />
          Saved Itineraries
        </h3>
        <p className="text-[11px] text-slate-400">Offline Collection cached in Local Storage.</p>
      </div>

      {savedPlans.length === 0 ? (
        <div className="text-center py-6 px-4 border border-dashed border-slate-200 rounded-xl space-y-2">
          <div className="h-8 w-8 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center mx-auto">
            <Compass className="h-4 w-4 animate-pulse-slow" />
          </div>
          <div className="space-y-0.5">
            <p className="text-[11px] font-bold text-slate-700">No Saved Plans Yet</p>
            <p className="text-[10px] text-slate-400 max-w-[180px] mx-auto leading-relaxed">Itineraries will appear here once synthesized & saved.</p>
          </div>
        </div>
      ) : (
        <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
          {savedPlans.map((plan) => (
            <div
              id={`history-item-${plan.id}`}
              key={plan.id}
              className={`flex items-center justify-between p-3 rounded-xl border transition group cursor-pointer ${
                selectedId === plan.id
                  ? 'bg-slate-50 border-indigo-500'
                  : 'bg-white border-slate-150 hover:bg-slate-50/50'
              }`}
              onClick={() => onSelect(plan)}
            >
              <div className="min-w-0 flex-1 space-y-1">
                <div className="flex items-center gap-1 text-slate-800">
                  <MapPin className="h-3 w-3 shrink-0 text-slate-400" />
                  <p className="text-xs font-bold truncate tracking-tight">
                    {plan.destination}
                  </p>
                </div>
                
                <div className="flex items-center gap-1.5 text-[9px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                  <span className="flex items-center gap-0.5">
                    <Calendar className="h-2.5 w-2.5 shrink-0" />
                    {plan.duration} Days
                  </span>
                  <span>•</span>
                  <span>{plan.style}</span>
                </div>
              </div>

              <button
                id={`del-history-${plan.id}`}
                type="button"
                className="p-1 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded transition cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(plan.id);
                }}
                title="Remove itinerary"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
