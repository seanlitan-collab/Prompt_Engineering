/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TripRequest, Itinerary } from '../domain/entities';

/**
 * Interface mapping to an external gateway/repository.
 * According to Clean Architecture, this adapter interface allows our Use Cases
 * to interact with external systems (like Gemini AI) without knowing their details.
 */
export interface ItineraryGateway {
  generate(request: TripRequest): Promise<Itinerary>;
}
