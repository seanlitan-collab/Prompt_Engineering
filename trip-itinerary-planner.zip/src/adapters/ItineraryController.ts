/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Request, Response } from 'express';
import { GenerateItineraryUseCase } from '../usecases/GenerateItineraryUseCase';
import { TravelStyle, BudgetLevel } from '../domain/entities';

/**
 * Interface Adapter: Controller layer.
 * Receives input from the network context (Express), validates and sanitizes it,
 * executes the Use Case, and returns clean, serialized output to the user.
 * Proactively defends against OWASP top vulnerabilities (XSS, Injection) via strict sanitization.
 */
export class ItineraryController {
  constructor(private readonly generateItineraryUseCase: GenerateItineraryUseCase) {}

  public async generateItinerary(req: Request, res: Response): Promise<void> {
    try {
      const { destination, duration, style, budget, customPreferences } = req.body;

      // 1. Strict Server-Side Input validation and Sanitization
      if (destination === undefined || destination === null) {
        res.status(400).json({ error: 'Destination is required.' });
        return;
      }

      if (typeof destination !== 'string') {
        res.status(400).json({ error: 'Destination must be a text value.' });
        return;
      }

      // Keep tags, scripts and unwanted injections out of destination (Simple XSS protection)
      const sanitizedDestination = destination
        .replace(/<[^>]*>/g, '') // strip HTML tags
        .trim();

      if (!sanitizedDestination) {
        res.status(400).json({ error: 'Destination cannot be empty.' });
        return;
      }

      const parsedDuration = Number(duration);
      if (isNaN(parsedDuration)) {
        res.status(400).json({ error: 'Duration must be a numeric integer value.' });
        return;
      }

      const validStyles: TravelStyle[] = ['adventure', 'relaxation', 'culture', 'foodie', 'family', 'romantic', 'general'];
      if (!validStyles.includes(style as any)) {
        res.status(400).json({ error: `Style must be one of: ${validStyles.join(', ')}` });
        return;
      }

      const validBudgets: BudgetLevel[] = ['budget', 'midrange', 'luxury'];
      if (!validBudgets.includes(budget as any)) {
        res.status(400).json({ error: `Budget must be one of: ${validBudgets.join(', ')}` });
        return;
      }

      let sanitizedPreferences = '';
      if (customPreferences !== undefined && customPreferences !== null) {
        if (typeof customPreferences !== 'string') {
          res.status(400).json({ error: 'Custom preferences must be a text value if specified.' });
          return;
        }
        sanitizedPreferences = customPreferences
          .replace(/<[^>]*>/g, '') // strip HTML tags
          .trim();
      }

      // 2. Execute the Use Case
      const itinerary = await this.generateItineraryUseCase.execute({
        destination: sanitizedDestination,
        duration: parsedDuration,
        style: style as TravelStyle,
        budget: budget as BudgetLevel,
        customPreferences: sanitizedPreferences,
      });

      // 3. Robust JSON serialization with standard safety headers (set by Express)
      res.status(200).json(itinerary);
    } catch (error: any) {
      console.error('ItineraryController Error:', error);
      res.status(400).json({
        error: error.message || 'An error occurred while generating the itinerary.',
      });
    }
  }
}
