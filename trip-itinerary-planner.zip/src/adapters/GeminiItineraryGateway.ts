/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from '@google/genai';
import { TripRequest, Itinerary, TravelStyle, BudgetLevel, Activity, DayPlan, PackingItem } from '../domain/entities';
import { ItineraryGateway } from './ItineraryGateway';

/**
 * Gemini-powered implementation of ItineraryGateway.
 * Translates Clean Architecture high-level policies into Google @google/genai calls.
 */
export class GeminiItineraryGateway implements ItineraryGateway {
  constructor(private readonly aiClient: GoogleGenAI) {}

  public async generate(request: TripRequest): Promise<Itinerary> {
    const preferencesPrompt = request.customPreferences 
      ? `Additionally, tailor this to these specific preferences: "${request.customPreferences}".` 
      : '';

    const modelName = 'gemini-3.5-flash';
    const systemInstruction = 
      `You are an expert, award-winning travel architect and local guide. ` +
      `Your goal is to build highly specific, realistic, and delightful day-by-day travel itineraries. ` +
      `All activities must be coherent, logistically sound, and realistic for a human to complete in a single day. ` +
      `Include local transport mechanisms, actual named venues and attractions, and correct currency expressions. ` +
      `Provide helpful insider tips for each day to make the travel experience outstanding. ` +
      `Ensure that the number of days returned matches EXACT REPORTED duration EXACTLY.`;

    const promptText = 
      `Create a day-by-day, travel-expert curated trip itinerary for: ${request.destination}.\n` +
      `- Duration: ${request.duration} days\n` +
      `- Travel Vibe/Style: ${request.style}\n` +
      `- Budget Category: ${request.budget}\n` +
      `${preferencesPrompt}\n\n` +
      `Please return the itinerary strictly formatted block JSON conforming EXACTLY to the specified output schema.`;

    try {
      const response = await this.aiClient.models.generateContent({
        model: modelName,
        contents: promptText,
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              destination: { type: Type.STRING, description: "Normalized name of the destination (City, Country)" },
              overview: { type: Type.STRING, description: "A robust, high-quality introductory summary of the trip" },
              days: {
                type: Type.ARRAY,
                description: "Day-by-day blocks detailing what to do",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    dayNumber: { type: Type.INTEGER, description: "The 1-based index of the day" },
                    theme: { type: Type.STRING, description: "A catchy descriptive theme or name for this day (e.g. 'Old Town Wonders')" },
                    dailyTip: { type: Type.STRING, description: "A context-aware local tip for this day (e.g. 'Buy the metro day card' or 'Dress modestly for temples')" },
                    estimatedCost: { type: Type.STRING, description: "The total estimated cost range for this specific day (e.g., '$40 - $70' or '$150')" },
                    activities: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          title: { type: Type.STRING, description: "Name/Topic of the activity" },
                          timeSlot: { type: Type.STRING, description: "Must be exactly one of: 'morning', 'afternoon', or 'evening'" },
                          timeRange: { type: Type.STRING, description: "Typical clock representation for this slot (e.g., '09:00 AM - 11:30 AM')" },
                          description: { type: Type.STRING, description: "Engaging descriptive summary of what to explore and see, including food options if applicable" },
                          location: { type: Type.STRING, description: "The specific landmark, street, or venue name" },
                          estimatedCost: { type: Type.STRING, description: "Cost for a traveler matching this budget category (e.g., '$15', 'Free', or '$120')" },
                          category: { type: Type.STRING, description: "Must be exactly one of: 'food', 'sightseeing', 'adventure', 'shopping', 'relaxation', 'transport'" }
                        },
                        required: ["title", "timeSlot", "timeRange", "description", "location", "estimatedCost", "category"]
                      }
                    }
                  },
                  required: ["dayNumber", "theme", "dailyTip", "estimatedCost", "activities"]
                }
              },
              packingList: {
                type: Type.ARRAY,
                description: "Handcrafted specific list of packing items perfect for this destination, season and style",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    item: { type: Type.STRING },
                    category: { type: Type.STRING, description: "Must be exactly one of: 'clothing', 'electronics', 'documents', 'essentials', 'other'" },
                    reason: { type: Type.STRING, description: "Brief traveler advice on why this is relevant" }
                  },
                  required: ["item", "category", "reason"]
                }
              },
              practicalInfo: {
                type: Type.OBJECT,
                description: "Quick reference for practical details",
                properties: {
                  currency: { type: Type.STRING, description: "Local currency name and code" },
                  language: { type: Type.STRING, description: "Primary spoken language and helpful greeting" },
                  transportTip: { type: Type.STRING, description: "Best way to navigate (e.g. metro, walk, cabs)" },
                  safetyTip: { type: Type.STRING, description: "Important local safety advice" },
                  bestTimeToVisit: { type: Type.STRING, description: "Optimal months to visit this destination" }
                },
                required: ["currency", "language", "transportTip", "safetyTip", "bestTimeToVisit"]
              }
            },
            required: ["destination", "overview", "days", "packingList", "practicalInfo"]
          }
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error('Gemini AI returned empty content.');
      }

      const parsed = JSON.parse(responseText.trim());

      // Map raw response schema perfectly to our rich Entities, securing ID assignments and default structures
      const itineraryId = 'itinerary_' + Math.random().toString(36).substring(2, 11);
      
      const mappedDays: DayPlan[] = (parsed.days || []).map((d: any) => {
        const activities: Activity[] = (d.activities || []).map((act: any, aIdx: number) => {
          // Strict sanitization of categories and formats
          const validatedCategory = ['food', 'sightseeing', 'adventure', 'shopping', 'relaxation', 'transport'].includes(act.category)
            ? act.category
            : 'sightseeing';

          const validatedTimeSlot = ['morning', 'afternoon', 'evening'].includes(act.timeSlot)
            ? act.timeSlot
            : (aIdx === 0 ? 'morning' : aIdx === 1 ? 'afternoon' : 'evening');

          return {
            id: `act_${d.dayNumber}_${aIdx}_${Math.random().toString(36).substring(2, 7)}`,
            title: String(act.title || 'Sightseeing activity'),
            timeSlot: validatedTimeSlot as 'morning' | 'afternoon' | 'evening',
            timeRange: String(act.timeRange || ''),
            description: String(act.description || ''),
            location: String(act.location || 'Local area'),
            estimatedCost: String(act.estimatedCost || 'Varies'),
            category: validatedCategory as any
          };
        });

        return {
          dayNumber: Number(d.dayNumber),
          theme: String(d.theme || `Exploring Day ${d.dayNumber}`),
          activities,
          dailyTip: String(d.dailyTip || 'Enjoy your day!'),
          estimatedCost: String(d.estimatedCost || 'Varies')
        };
      });

      const mappedPacking: PackingItem[] = (parsed.packingList || []).map((item: any) => {
        const categories = ['clothing', 'electronics', 'documents', 'essentials', 'other'];
        const category = categories.includes(item.category) ? item.category : 'essentials';
        return {
          item: String(item.item),
          category: category as any,
          reason: String(item.reason)
        };
      });

      const mappedItinerary: Itinerary = {
        id: itineraryId,
        destination: String(parsed.destination || request.destination),
        duration: request.duration,
        style: request.style,
        budget: request.budget,
        overview: String(parsed.overview || ''),
        days: mappedDays,
        packingList: mappedPacking,
        practicalInfo: {
          currency: String(parsed.practicalInfo?.currency || 'Local Dollar'),
          language: String(parsed.practicalInfo?.language || 'Local language'),
          transportTip: String(parsed.practicalInfo?.transportTip || 'Walkable or public ride'),
          safetyTip: String(parsed.practicalInfo?.safetyTip || 'Standard city awareness'),
          bestTimeToVisit: String(parsed.practicalInfo?.bestTimeToVisit || 'All-year round')
        },
        createdAt: Date.now()
      };

      return mappedItinerary;
    } catch (error: any) {
      console.error('GeminiItineraryGateway generation error:', error);
      throw new Error(`Failed to generate travel plan from Gemini AI: ${error?.message || error}`);
    }
  }
}
