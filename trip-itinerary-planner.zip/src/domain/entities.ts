/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Domain-level types and validation rules (Entities).
 * Zero dependencies on frameworks, databases, or third-party SDKs.
 */

export type TravelStyle = 'adventure' | 'relaxation' | 'culture' | 'foodie' | 'family' | 'romantic' | 'general';
export type BudgetLevel = 'budget' | 'midrange' | 'luxury';

export interface Activity {
  id: string;
  title: string;
  timeSlot: 'morning' | 'afternoon' | 'evening';
  timeRange: string; // e.g. "09:00 AM - 11:30 AM"
  description: string;
  location: string;
  estimatedCost: string; // e.g., "$15" or "Free"
  category: 'food' | 'sightseeing' | 'adventure' | 'shopping' | 'relaxation' | 'transport';
}

export interface DayPlan {
  dayNumber: number;
  theme: string; // e.g. "Historic Quarter Exploration"
  activities: Activity[];
  dailyTip: string;
  estimatedCost: string;
}

export interface PackingItem {
  item: string;
  category: 'clothing' | 'electronics' | 'documents' | 'essentials' | 'other';
  reason: string;
}

export interface LocalInformation {
  currency: string;
  language: string;
  transportTip: string;
  safetyTip: string;
  bestTimeToVisit: string;
}

export interface Itinerary {
  id: string;
  destination: string;
  duration: number;
  style: TravelStyle;
  budget: BudgetLevel;
  overview: string;
  days: DayPlan[];
  packingList: PackingItem[];
  practicalInfo: LocalInformation;
  createdAt: number;
}

/**
 * Enterprise entity representing a validated Request for generating a trip.
 */
export class TripRequest {
  constructor(
    public readonly destination: string,
    public readonly duration: number,
    public readonly style: TravelStyle,
    public readonly budget: BudgetLevel,
    public readonly customPreferences: string = ''
  ) {
    this.validate();
  }

  /**
   * Enterprise business rules for a valid trip request.
   */
  private validate(): void {
    if (!this.destination || typeof this.destination !== 'string' || this.destination.trim() === '') {
      throw new Error('Destination must be a valid non-empty string.');
    }
    
    // Sanitize destination
    if (this.destination.length > 100) {
      throw new Error('Destination name is too long (maximum 100 characters).');
    }

    if (!Number.isInteger(this.duration) || this.duration < 1 || this.duration > 14) {
      throw new Error('Trip duration must be a whole number between 1 and 14 days.');
    }

    const validStyles: TravelStyle[] = ['adventure', 'relaxation', 'culture', 'foodie', 'family', 'romantic', 'general'];
    if (!validStyles.includes(this.style)) {
      throw new Error(`Invalid travel style: ${this.style}`);
    }

    const validBudgets: BudgetLevel[] = ['budget', 'midrange', 'luxury'];
    if (!validBudgets.includes(this.budget)) {
      throw new Error(`Invalid budget level: ${this.budget}`);
    }

    if (this.customPreferences && this.customPreferences.length > 500) {
      throw new Error('Custom preferences description is too long (maximum 500 characters).');
    }
  }

  /**
   * Helper to serialize the object safely.
   */
  public toJSON() {
    return {
      destination: this.destination.trim(),
      duration: this.duration,
      style: this.style,
      budget: this.budget,
      customPreferences: this.customPreferences.trim()
    };
  }
}
